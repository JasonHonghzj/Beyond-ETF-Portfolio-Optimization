library(randomForest)
library(ggplot2)
library(caret)
library(caTools)
library(readxl)

setwd("C:\\Users\\user\\OneDrive\\Desktop\\stock_data\\")
symbol <- c("2317","2330","2395","2357","3231","2207","2603",
            "3034","3045","2002","6669","1216","2303","3711",
            "2308","2412","2382","2454","2881","2885","2886","6505")

df <- data.frame(symbol=symbol)
rmse_df <- c()
return_df <- c()


for (i in 1:length(symbol)) {
  filename = paste(symbol[i],"_daily.xlsx",sep="")
  
  data = read_xlsx(filename)
  data = as.data.frame(data)
  data$date = as.Date(data$date)
  data = data[order(data$date), ]
  data_ts <- ts(data$close, start = c(2019, 1), frequency = 250)
  
  
  
  data_ts_list_x <- list()
  data_ts_list_y <- list()
  
  lookback =20 
  n <- length(data_ts);n
  
  
  for(i in 1:(n-lookback)){
    lookback <- 20 
    data_temp <- data_ts[i:(i+lookback-1)]
    data_ts_list_x[[i]] <- data_temp
    data_ts_list_y[[i]] <- data_ts[i+lookback]
  }
  
  my_df_x <- as.data.frame(do.call(rbind, data_ts_list_x))
  #my_df_x
  
  my_df_y <- as.data.frame(do.call(rbind, data_ts_list_y))
  #my_df_y
  
  data <- cbind(my_df_x,my_df_y)
  #data
  
  colnames(data)[21] <- "y"
  #data
  
  n = nrow(data)
  draw = round(n*0.8) 
  train_data = data[1:draw, ] 
  test_data = data[(draw+1):n, ] 
  nrow(train_data);nrow(test_data) #[1] 940 [1] 235
  
  set.seed(1)
  model <- randomForest(y~.,train_data)
  model
  pred = predict(model, newdata = test_data)
  
  rmse <- sqrt(mean((pred - test_data$y)^2))
  return <- ((pred[length(pred)]-pred[1])/pred[1]) *100 
  
  rmse_df <- c(rmse_df,rmse)
  return_df <- c(return_df,return)
  
}

rmse_df;return_df

df <- data.frame(symbol=symbol)
df_1 <- cbind(df, rmse = round(rmse_df,2) ,return = round(return_df,2))
df_2 <- df_1[order(df_1$return), ]

print(df_2)









close_1216 = as.numeric(stock_1216$close)
n = length(data_ts)
n
# [1] 1195
#split_data <- function(stock, lookback) {
data_raw <- as.matrix(stock) 
data <- list()

for (index in 1:(nrow(data_raw) - lookback)) {
  data[[index]] <- data_raw[index:(index + lookback - 1), , drop = FALSE]
}

data <- array(unlist(data), dim = c(length(data), ncol(data_raw), lookback))

test_set_size <- as.integer(round(0.2 * dim(data)[1]))
print(test_set_size)
train_set_size <- dim(data)[1] - test_set_size

x_train <- data[1:train_set_size, 1:(ncol(data_raw) - 1), ]
y_train <- data[1:train_set_size, ncol(data_raw), ]

x_test <- data[(train_set_size + 1):dim(data)[1], 1:(ncol(data_raw) - 1), ]
y_test <- data[(train_set_size + 1):dim(data)[1], ncol(data_raw), ]

return(list(x_train = x_train, y_train = y_train, x_test = x_test, y_test = y_test))
}


lookback <- 20 # choose sequence length
result <- split_data(data_ts, lookback)
print(paste('x_train.shape = ', dim(result$x_train)))
print(paste('y_train.shape = ', dim(result$y_train)))
print(paste('x_test.shape = ', dim(result$x_test)))
print(paste('y_test.shape = ', dim(result$y_test)))