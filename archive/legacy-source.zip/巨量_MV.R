R = 100* (log(data[-1,])-log(data[-218,]))
mean_vect = apply(R,2,mean)
cov_mat = cov(R)
sd_vect = sqrt(diag(cov_mat))
# set the constraints matrix
Amat = cbind(rep(1,6),mean_vect,diag(1,nrow = ncol(R)))  

# set of 300 possible target values #######
muP = seq(min(mean_vect) + 0.0001, max(mean_vect) - 0.0001,length = 300)  

# set up storage for std dev's of portfolio returns
sdP = muP 

# storage for portfolio weights
weights = matrix(0,nrow = length(muP),ncol = ncol(R)) 

# find the optimal portfolios for each target expected return
for (i in 1:length(muP)) {
  bvec = c(1,muP[i],rep(0,ncol(R)))  # constraint vector   ######
  result =  solve.QP(Dmat = 2*cov_mat,
                     dvec = rep(0,ncol(R)),
                     Amat = Amat,
                     bvec = bvec,meq = 2) 
  sdP[i] = sqrt(result$value)
  weights[i,] = result$solution
  #  meq = number of equations in constraint matrix
  #  result$value is risk of optimal portfolio
  #  result$solution is weight of optimal portfolio
}
mufree = 1.565/299
sharpe = (muP-mufree) / sdP 
ind = (sharpe == max(sharpe)) # Find maximum Sharpe's ratio
weights[ind,]

#muP 就是expected return