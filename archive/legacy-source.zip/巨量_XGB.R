library(xgboost)
library(ggplot2)

library(caret)
library(caTools)
stock_1216 = read_xlsx("C:/Downloads/daily_/stock/1216_daily.xlsx")
stock_1216$date = as.Date(stock_1216$date)
stock_1216 = stock_1216[order(stock_1216$date), ]
#close_1216 = as.numeric(stock_1216$close)
n_1216 = length(stock_1216$close)
year_1216 = 2019+(1:n_1216)*(2024-2019)/n_1216 # for plot

# 訓練集、測試集
set.seed(123)
train_size = round(n_1216*0.8) #[1] 956
training_set = stock_1216[1:956, ]
test_set = stock_1216[957:1195, ]
X_train = as.matrix(training_set[, -c(1,9)])  # Remove the date,No column
y_train = as.numeric(training_set$close)

xgbmodel_1216 = xgboost(data = X_train, label = as.numeric(y_train), nrounds = 10)
X_test = as.matrix(test_set[, -c(1,9)])
y_test = as.numeric(test_set$close)
pred = predict(xgbmodel_1216, newdata = X_test)
results = data.frame(Actual = y_test, Predicted = pred)
# 計算MAE評估模型
mae = mean(abs(results$Actual - results$Predicted)) # [1] 1.950484

ggplot() +
  geom_line(data = training_set, aes(x = training_set$date, y = close, color = "Train"), size = 0.3) +
  geom_line(data = results, aes(x = test_set$date, y = Actual, color = "Actual"), linetype = "dashed") +
  geom_line(data = results, aes(x = test_set$date, y = Predicted, color = "Predicted")) +
  labs(x = "Date", y = "Price", title = "Actual vs Predicted") +
  scale_color_manual(values = c("Train" = "black", "Actual" = "blue", "Predicted" = "red")) +
  theme_minimal()

'''
用整理好的rolling window 資料訓練XGBoost模型
X_train <- train_data[, 1:20]
y_train <- train_data[, 21]
X_test <- test_data[, 1:20]
pred <- predict(model, as.matrix(X_test))
model <- xgboost(data = as.matrix(X_train), label = y_train, nrounds = 10)
'''
