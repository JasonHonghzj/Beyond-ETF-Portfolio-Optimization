library(forecast)
library(readxl)

#ETF
setwd("C:\\Users\\user\\OneDrive\\Desktop\\ETF\\")

symbol <- c("0050", "0056", "00646", "00692", "00712",
            "00713","00733", "00757", "00830", "006208")

#Stock
setwd("C:\\Users\\user\\OneDrive\\Desktop\\stock_data\\")

symbol <- c("2330", "2317", "2454", "2382", "2412", "2881", "2308", "2882"
            , "6505", "3711","2303", "2891", "2886", "1303", "1301",
            "1216", "2884", "6669", "2002", "3045","2885", "5880", "3034", 
            "2892", "2603","2207", "3231", "2357", "2395", "1326")
#畫圖
for (i in 1:length(symbol)){
  filename <- paste(symbol[i],"_daily.xlsx",sep = "")
  data <- read_xlsx(filename)
  data <- as.data.frame(data)
  data$date <- as.Date(data$date)
  data <- data[order(data$date), ]
  rownames(data) <- NULL
  data_ts <- ts(data$close,start=c(2019,1), frequency=299)
  data_ts = diff(log(data_ts))
}

#畫CCF圖
stock1 <- diff(log(AAPL$close))
stock2 <- diff(log(GOOG$close))  
# 確保數據對齊
stocks <- na.omit(merge(stock1, stock2))
# 使用ccf計算並繪製互相關
ccf_result <- ccf(stocks[,1], stocks[,2], lag.max=10, main="Cross-correlation between AAPL and GOOG")

#儲存圖片
'''
plot_filename <- paste("C:\\Users\\user\\OneDrive\\Desktop\\stock_data\\", symbol[i], "_plot.png", sep = "")
ggsave(plot_filename, plot = p, width = 10, height = 8, dpi = 300)
'''
#CCF圖
ibrary(ggplot2)
library(caret)
library(caTools)
stock_1216 = read_xlsx("C:/Downloads/daily_/stock/1216_daily.xlsx")
stock_1216$date = as.Date(stock_1216$date)
stock_1216 = stock_1216[order(stock_1216$date), ]
#close_1216 = as.numeric(stock_1216$close)
n_1216 = length(stock_1216$close)
year_1216 = 2019+(1:n_1216)*(2024-2019)/n_1216 # for plot


#畫選出來的22支stock時序圖
symbol <- c("2317", "2382", "2412",
            "2881", "2882", "6505", "3711",
            "2303", "2891", "2886", "1303", "1301",
            "1216", "2884", "3045",
            "2885", "5880", "2892", "2603",
            "3231", "1326")


data <- data.frame()
for (i in 1:length(symbol)){
  filename <- paste(symbol[i],"_daily.xlsx",sep = "")
  data_temp <- read_xlsx(filename)
  data_temp <- as.data.frame(data_temp)
  data_temp$date <- as.Date(data_temp$date)
  data_temp <- data_temp[order(data_temp$date), ]
  rownames(data_temp) <- NULL
  data_temp$group <- symbol[i]
  data <- rbind(data,data_temp)
}
library(ggplot2)
ggplot(data, aes(x = date, y = close, color = group)) +
  geom_line() +
  labs(title = "Stock Price Trend",
       x = "Date",
       y = "Close Price",
       color = "ETF Symbol") +
  theme_minimal()
ggplot(data, aes(x = date, y = close, color = group)) +
  geom_line() +
  labs(title = "Stock Price Trend",
       x = "Date",
       y = "Close Price",
       color = "Stock Price Symbol") +
  theme_minimal()




# 用自製的30筆未差分資料畫相關性圖
cor_matrix <- matrix(nrow = 30, ncol = 30)
rownames(cor_matrix) <- symbol
colnames(cor_matrix) <- symbol
for (i in 1:30){
  for (j in 1:30){
    if (i<j) {
      filename1 <- paste("C:\\Users\\user\\OneDrive\\Desktop\\stock_data\\",symbol[i],"_daily.xlsx",sep = "")
      filename2 <- paste("C:\\Users\\user\\OneDrive\\Desktop\\stock_data\\",symbol[j],"_daily.xlsx",sep = "")
      data1 <- read_xlsx(filename1)
      data1 <- as.data.frame(data1)
      data1$date <- as.Date(data1$date)
      data1 <- data1[order(data1$date), ]
      data2 <- read_xlsx(filename2)
      data2 <- as.data.frame(data2)
      data2$date <- as.Date(data2$date)
      data2 <- data2[order(data2$date), ]
      rownames(data1) <- NULL
      rownames(data2) <- NULL
      stocks <- merge(data1, data2, by = "date", all = FALSE)
      cor <- cor(diff(log(stocks[,5])), diff(log(stocks[,12])))
      cor_matrix[i,j] <- cor
    }
  }
}

g <- graph.empty(n = 30, directed = FALSE)
# 设置图的节点名称
V(g)$name <- symbol
# 添加边，只添加相关性小于0.6的边
for (i in 1:29) {
  for (j in (i+1):30) {
    if (!is.na(cor_matrix[i, j]) && abs(cor_matrix[i, j]) < 0.6) {
      g <- add_edges(g, c(symbol[i], symbol[j]))
    }
  }
}
# 找到最大团
max_cliques <- largest_cliques(g)

# 打印最大团的股票名
if (length(max_cliques) > 0) {
  largest_clique <- max_cliques[[which.max(sapply(max_cliques, length))]]
  print(largest_clique)
} else {
  print("No cliques found with the specified correlation threshold.")
}

