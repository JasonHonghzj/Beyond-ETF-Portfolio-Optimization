#ETF 選出來的8支 - 2023報酬率
setwd("C:\\Users\\user\\OneDrive\\Desktop\\ETF\\")
library(readxl)
symbol <- c("0050", "0056", "00646", "00692", "00712",
            "00713","00733", "00757", "00830", "006208")

return_list = c()
for (i in 1:length(symbol)){
  filename <- paste(symbol[i],"_daily.xlsx",sep = "")
  data <- read_xlsx(filename)
  data <- as.data.frame(data)
  data$date <- as.Date(data$date)
  rownames(data) <- NULL
  data_ts <- ts(data$close,start=c(2019,1), frequency=299)
  data[c(1,218),c(1,5)]
  return_rate = round(100*(data[1,5]-data[218,5]) / data[218,5],digits = 2)
  result = paste('2023',symbol[i],'報酬率：',return_rate, '%')
  return_list = c(return_list,return_rate)
  print(result)
}

data = data.frame('報酬率' = c(40.40,38.8,39.57,return_list),
                  "group" = c('MV','BL','1/N',symbol))
data <- data[order(data$報酬率,decreasing = T), ]
rownames(data) = seq(1,13,1)

legend = factor(data$group,levels = data$group)

library(ggplot2)
ggplot(data, aes(x = legend, y = 報酬率, fill = legend)) +
  geom_bar(stat = "identity", position = "dodge") +
  labs(title = " ", x = " ", y = "Return (%)") +
  scale_fill_manual(values = c("MV" = "coral", "BL" = "#2E9FDF", "1/N" = "#E7B800", "0050" = "gray", 
                               "0056" = "gray", "00646" = "gray", "00692" = "gray",
                               "00712" = "gray", "00713" = "gray", "00733" = "#333333",
                               "00757" = "#333333", "00830" = "#333333", "006208" = "gray")) +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1,size=26)
        ,axis.text.y = element_text(size = 18)
        ,legend.text = element_text(size=14))
