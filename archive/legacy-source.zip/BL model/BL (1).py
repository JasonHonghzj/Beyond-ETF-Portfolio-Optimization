#!/usr/bin/env python
# coding: utf-8

# In[1]:


class BL_Model:
    def __init__(self, K, N, tau, lamb, w0, P, Q, ret):
        # dimension
        self.K = K
        self.N = N
        # parameter
        self.tau = tau
        self.lamb = lamb
        self.w = w0
         ###------------ investor's view ------------###
        self.P = self.test_P(P, self.K, self.N)
        self.Q = self.test_Q(Q, self.K)
        ###------------ implied return ------------###
        self.sigma = self.get_sigma(ret)
        self.pi = self.get_pi(self.lamb, self.sigma, self.w)
        self.A = self.get_A(self.tau, self.sigma)
        ###------------ required return ------------###
        self.omega = self.get_omega(self.tau, self.P, self.sigma)
        self.B = self.get_B(self.P, self.omega)
        self.expRet = self.get_expRet(self.A, self.B, self.pi, self.omega, self.P, self. Q)
    
    def test_P(self, P, k, n):
        P = np.array(P)
        assert P.shape[0] == k, "[Error]: Row dimension of P should be {0}, but {1}".format(k, P.shape[0])
        assert P.shape[1] == n, "[Error]: Col dimension of P should be {0}, but {1}".format(n, P.shape[1])
        sum_over_vec = np.apply_along_axis(np.sum, axis=1, arr=P)
        assert sum_over_vec.sum() == 0, "Sum over each vector should be zero, but received {}".format(sum_over_vec)
        return P
    
    def test_Q(self, Q, k):
        Q = np.array(Q).reshape(3, 1)
        assert Q.shape[0] == k, "[Error]: Row dimension of Q should be {0}, but {1}".format(k, Q.shape[0])
        assert Q.shape[1] == 1, "[Error]: Col dimension of Q should be 1, but {}".format(Q.shape[1])
        return Q
    
    def get_expRet(self, A, B, pi, omega, P, Q):
        """Expected return to optimal
        """
        denom = inv(A+B)
        nom = (A@pi + P.T @ inv(omega) @ Q )
        obj = denom@nom
        assert obj.shape[0] == self.N, "[Error]: Row dimension of obj should be {0}, but {1}".format(self.N, obj.shape[0])
        assert obj.shape[1] == 1, "[Error]: Col dimension of obj should be {0}, but {1}".format(1, obj.shape[1])
        return obj

    def get_A(self, tau, sigma):
        return inv(tau*sigma)

    def get_B(self, P, omega):
        return P.T @ np.linalg.inv(omega) @ P

    ###------------ implied return ------------###
    def get_pi(self, lamb, sigma, w):
        pi = (lamb * sigma @ w).reshape(-1, 1)
        assert pi.shape[0] == self.N, "[Error]: Row dimension of pi should be {0}, but {1}".format(self.N, pi.shape[0])
        assert pi.shape[1] == 1, "[Error]: Col dimension of pi should be {0}, but {1}".format(1, pi.shape[1])
        return pi

    def get_sigma(self, ret):
        return np.cov(ret, rowvar=False)

    ###------------ required return ------------###
    def get_omega(self, tau, P, sigma):
        omega = tau * P @ sigma @ P.T
        assert omega.shape[0] == self.K, "[Error]: Row dimension of omega should be {0}, but {1}".format(self.K, omega.shape[0])
        assert omega.shape[1] == self.K, "[Error]: Col dimension of omega should be {0}, but {1}".format(self.K, omega.shape[1])
        return omega


# In[2]:


import pandas as pd
import numpy as np
from scipy.linalg import inv




# In[3]:


data = pd.read_excel("D:/2024_spring/Big_data/project/working_data/return_1.xlsx")

data.head()


# In[4]:


data.shape


# In[5]:


import numpy as np


Q = np.array([0.4, 0.1, 0.04]).reshape(-1, 1)


P = np.array([
    [1, 0, 0, 0, 0, -1],
    [0, 1, -1, 0, 0, 0],
    [0, 0, 1, -1, 0, 0]
])



# In[6]:


# 初始化 BL_Model 类的实例
bl_model = BL_Model(
    K=3,  # 根据 Q 的长度确定
    N=6,  # 股票数量
    tau=0.25,  # 根据模型参数确定
    lamb=0.5,  # 根据模型参数确定
    w0=np.ones(6) / 6,  # 假设等权重
    P=P,
    Q=Q,
    ret=data
)


# In[7]:


# pip install autograd
from scipy.optimize import minimize


# In[8]:


from autograd import jacobian, hessian

class BLM_Optim(BL_Model):
    def __init__(self, K, N, tau, lamb, w0, P, Q, ret, w_min=0, w_max=1):
        super().__init__(K, N, tau, lamb, w0, P, Q, ret)
        self.w_min = w_min
        self.w_max = w_max
        ##### import from autograd module
        self.jacb_func = jacobian(self.obj) 
        self.hess_func = hessian(self.obj) 
        ##### for optimal 
        self.constraints = [
            {'type': 'eq', 'fun': self.total_weight_equal_one_constraint},
            {'type': 'ineq', 'fun': self.long_only_constraint}
        ]
        self.bound = self.get_bound()

    
    def obj(self, w):
        self.pi = self.get_pi(self.lamb, self.sigma, w)
        self.expRet = self.get_expRet(self.A, self.B, self.pi, self.omega, self.P, self.Q)
        return -w@self.expRet

    def total_weight_equal_one_constraint(self, w):
        return np.sum(w)-1.0

    def long_only_constraint(self, w):
        return w

    def get_bound(self):
        return tuple((self.w_min, self.w_max) for i in range(self.N))
        
    def jacb_val(self, w):
        return self.jacb_func(w).flatten()

    def hess_val(self, w):
        return self.hess_func(w)




# In[9]:


tau = 0.5
lamb = 0.5
w0 = np.array([1/6] * 6)
K=3
N=6
BLM =  BLM_Optim(K, N, tau, lamb, w0, P, Q, data, w_min=0, w_max=1)
        
res = minimize(fun=BLM.obj, 
               x0 = w0,
               #args = (lamb, sigma, omega, A, B, P, Q),
               method = "SLSQP",
               constraints = BLM.constraints,
               bounds = BLM.bound,
               tol = 1e-8
              )

print("Optimal function value : {}".format(res.fun))
print("Sum of weights : {}".format(np.sum(res.x)))
print("Optimal weights: \n{}".format(res.x))


# ###
# ### P、Q為主觀觀點 預期未來的return會是多少，可以是絕對或相對
# ### BL 模型會設C參數，C 通常是covariace 的倍數 (tau倍) 
# tau = 1/size(assetRetns.Variables, 1);
# C = tau*Sigma;

# In[10]:


from autograd import jacobian, hessian
from scipy.optimize import minimize

class BLM_Optim(BL_Model):
    def __init__(self, K, N, tau, lamb, w0, P, Q, ret, w_min=0, w_max=1):
        super().__init__(K, N, tau, lamb, w0, P, Q, ret)
        self.w_min = w_min
        self.w_max = w_max
        ##### import from autograd module
        self.jacb_func = jacobian(self.obj) 
        self.hess_func = hessian(self.obj) 
        ##### for optimal 
        self.constraints = [
            {'type': 'eq', 'fun': self.total_weight_equal_one_constraint},
            {'type': 'ineq', 'fun': self.long_only_constraint}
        ]
        self.bound = self.get_bound()

    
    def obj(self, w):
        self.pi = self.get_pi(self.lamb, self.sigma, w)
        self.expRet = self.get_expRet(self.A, self.B, self.pi, self.omega, self.P, self.Q)
        return -w @ self.expRet

    def total_weight_equal_one_constraint(self, w):
        return np.sum(w) - 1.0

    def long_only_constraint(self, w):
        return w

    def get_bound(self):
        return tuple((self.w_min, self.w_max) for i in range(self.N))
        
    def jacb_val(self, w):
        return self.jacb_func(w).flatten()

    def hess_val(self, w):
        return self.hess_func(w)


tau = 0.5
lamb = 0.5
w0 = np.array([1/6] * 6)
K = 3
N = 6
w_min = 0.1
w_max = 0.5  
BLM = BLM_Optim(K, N, tau, lamb, w0, P, Q, data, w_min=w_min, w_max=w_max)
        
res = minimize(fun=BLM.obj, 
               x0=w0,
               method="SLSQP",
               constraints=BLM.constraints,
               bounds=BLM.bound,
               tol=1e-8
              )

print("Optimal function value : {}".format(res.fun))
print("Sum of weights : {}".format(np.sum(res.x)))
print("Optimal weights: \n{}".format(res.x))


# In[ ]:




