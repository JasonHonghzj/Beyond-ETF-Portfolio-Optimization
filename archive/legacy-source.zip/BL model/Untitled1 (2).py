#!/usr/bin/env python
# coding: utf-8

# In[3]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt  
import yfinance as yf


# In[14]:


#!pip install yfinance 


# In[27]:


# data = pd.read_excel("D:/2024_spring/Big_data/project/working_data/all_close_data.xlsx")
# data.head()


# In[20]:


# prices = data


# In[17]:


tickers = ["3034.TW","2357.TW","2454.TW","2886.TW","3711.TW","2330.TW"]


# In[26]:


ohlc = yf.download(tickers, period="max")
prices = ohlc["Adj Close"]
prices.tail()


# In[22]:


market_prices = yf.download("0050.TW", period="max")["Adj Close"]
market_prices.head()


# In[18]:


mcaps = {}

# 遍歷每個股票代碼，獲取市值
for t in tickers:
    stock = yf.Ticker(t)
    mcaps[t] = stock.info["marketCap"]

# 打印市值字典
print(mcaps)


# ### Constructing the prior

# In[19]:


#!pip install PyPortfolioOpt


# In[ ]:


# pip install --upgrade pip


# In[15]:


import pypfopt


# In[28]:


from pypfopt import black_litterman, risk_models
from pypfopt import BlackLittermanModel, plotting

S = risk_models.CovarianceShrinkage(prices).ledoit_wolf()
delta = black_litterman.market_implied_risk_aversion(market_prices)
delta
     


# In[29]:


plotting.plot_covariance(S, plot_correlation=True);


# In[30]:


market_prior = black_litterman.market_implied_prior_returns(mcaps, delta, S)
market_prior


# In[31]:


market_prior.plot.barh(figsize=(10,5));


# In[ ]:


'3034.TW': 357805064192, '2357.TW': 349468590080, '2454.TW': 1742747205632, '2886.TW': 577214808064, '3711.TW': 654420869120, '2330.TW': 20799870205952


# In[44]:


# You don't have to provide views on all the assets
viewdict = {
    "3034.TW": 0.10,
    "2357.TW": 0.30,
    "2454.TW": 0.05,
    "2886.TW": 0.05,
    "3711.TW": 0.20,
    "2330.TW": 0.4,  # I think Coca-Cola will go down 5%
}

bl = BlackLittermanModel(S, pi=market_prior, absolute_views=viewdict)
     


# In[45]:


confidences = [
    0.6,
    0.4,
    0.2,
    0.5,
    0.7, # confident in dominos
    0.7
]


# In[46]:


bl = BlackLittermanModel(S, pi=market_prior, absolute_views=viewdict, omega="idzorek", view_confidences=confidences)
     


# In[47]:


fig, ax = plt.subplots(figsize=(7,7))
im = ax.imshow(bl.omega)

# We want to show all ticks...
ax.set_xticks(np.arange(len(bl.tickers)))
ax.set_yticks(np.arange(len(bl.tickers)))

ax.set_xticklabels(bl.tickers)
ax.set_yticklabels(bl.tickers)
plt.show()


# In[48]:


np.diag(bl.omega)


# In[49]:


intervals = [
    (0, 0.25),
    (0.1, 0.4),
    (-0.1, 0.15),
    (-0.05, 0.1),
    (0.15, 0.25),
    (-0.1, 0)
]


# In[50]:


variances = []
for lb, ub in intervals:
    sigma = (ub - lb)/2
    variances.append(sigma ** 2)

print(variances)
omega = np.diag(variances)


# In[51]:


# We are using the shortcut to automatically compute market-implied prior
bl = BlackLittermanModel(S, pi="market", market_caps=mcaps, risk_aversion=delta,
                        absolute_views=viewdict, omega=omega)


# In[52]:


# Posterior estimate of returns
ret_bl = bl.bl_returns()
ret_bl
     


# In[53]:


rets_df = pd.DataFrame([market_prior, ret_bl, pd.Series(viewdict)], 
             index=["Prior", "Posterior", "Views"]).T
rets_df


# In[54]:


rets_df.plot.bar(figsize=(12,8));


# In[55]:


S_bl = bl.bl_cov()
plotting.plot_covariance(S_bl);
     


# In[56]:


from pypfopt import EfficientFrontier, objective_functions


# In[57]:


ef = EfficientFrontier(ret_bl, S_bl)
ef.add_objective(objective_functions.L2_reg)
ef.max_sharpe()
weights = ef.clean_weights()
weights


# In[58]:


pd.Series(weights).plot.pie(figsize=(10,10));


# In[59]:


from pypfopt import DiscreteAllocation

da = DiscreteAllocation(weights, prices.iloc[-1], total_portfolio_value=20000)
alloc, leftover = da.lp_portfolio()
print(f"Leftover: ${leftover:.2f}")
alloc
     


# In[ ]:




