setwd("C:\\Users\\user\\OneDrive\\Desktop\\stock_data\\")
data <- matrix(nrow = 218,ncol=6)
symbol <- c(3034,2357,2454,2886,3711,2330)
for (i in 1:length(symbol)){
  filename <- paste("C:\\Users\\user\\OneDrive\\Desktop\\stock_data\\",symbol[i],"_daily.xlsx",sep = "")
  stock <- read_xlsx(filename)
  stock <- as.data.frame(stock)
  stock$date <- as.Date(stock$date)
  stock <- stock[order(stock$date), ]
  rownames(stock) <- NULL
  stock <- stock[978:1195,]
  stock <- stock$close
  data[,i] <- stock
}
colnames(data) <- symbol

data_etf <- matrix(nrow = 218,ncol=10)
symbols <- c("0050", "0056", "00646", "00692", "00712",
            "00713","00733", "00757", "00830", "006208")
for (i in 1:length(symbols)){
  filename <- paste("C:\\Users\\user\\OneDrive\\Desktop\\ETF\\",symbols[i],"_daily.xlsx",sep = "")
  etf <- read_xlsx(filename)
  etf <- as.data.frame(etf)
  etf$date <- as.Date(etf$date)
  etf <- etf[1:218,]
  etf <- etf[order(etf$date), ]
  rownames(etf) <- NULL
  etf <- etf$close
  data_etf[,i] <- etf
}
filename <- paste("C:\\Users\\user\\OneDrive\\Desktop\\ETF\\",symbols[1],"_daily.xlsx",sep = "")
etf <- read_xlsx(filename)
etf <- as.data.frame(etf)
etf$date <- as.Date(etf$date)
etf <- etf[1:218,]
etf <- etf[order(etf$date), ]
dates <- etf$date
# 转换矩阵为数据框
df <- as.data.frame(data_etf)

library(quadprog)
R = 100* (log(data[-1,])-log(data[-218,]))
mean_vect = apply(R,2,mean)
cov_mat = cov(R)
sd_vect = sqrt(diag(cov_mat))
# set the constraints matrix
Amat = cbind(rep(1,6),mean_vect,diag(1,nrow = ncol(R)))  

# set of 300 possible target values #######
muP = seq(min(mean_vect) + 0.0001, max(mean_vect) - 0.0001,length = 300)  

# set up storage for std dev's of portfolio returns
sdP = muP 

# storage for portfolio weights
weights = matrix(0,nrow = length(muP),ncol = ncol(R)) 

# find the optimal portfolios for each target expected return
for (i in 1:length(muP)) {
  bvec = c(1,muP[i],rep(0,ncol(R)))  # constraint vector   ######
  result =  solve.QP(Dmat = 2*cov_mat,
                     dvec = rep(0,ncol(R)),
                     Amat = Amat,
                     bvec = bvec,meq = 2) 
  sdP[i] = sqrt(result$value)
  weights[i,] = result$solution
  #  meq = number of equations in constraint matrix
  #  result$value is risk of optimal portfolio
  #  result$solution is weight of optimal portfolio
}
mufree = 1.565/100
sharpe = (muP-mufree) / sdP 
ind = (sharpe == max(sharpe)) # Find maximum Sharpe's ratio
final_w=weights[ind,] 
round(final_w*100,2)

#效率曲線圖
# connect the tangency portfolio and risk-free asset
par(cex.axis=1.2, cex.lab=1.3, cex.main=1.5)
plot(sdP,muP,type = "l",
     xlim = c(0,2.5),ylim = c(0.0,0.23),lty = 1,xlab="risk",ylab="return")  
points(0,mufree,cex = 1.5,pch = 4,lwd = 4)

x_cml <- c(0, sdP[ind])  # 从无风险点到切线投资组合的标准差
y_cml <- c(mufree, muP[ind])  # 从无风险点到切线投资组合的预期回报

# 绘制 CML
lines(x_cml, y_cml, lwd = 4, lty = 1, col = "blue")
# show line of optimal portfolios
points(sdP[ind],muP[ind],cex = 4,pch = "*") # show tangency portfolio

# index the minimum variance portfolio
ind2 = (sdP == min(sdP)) 
points(sdP[ind2],muP[ind2],cex = 2,pch = 1,lwd = 3) # show min var portfolio

# efficient frontier
ind3 = (muP > muP[ind2])
lines(sdP[ind3],muP[ind3],type = "l",xlim = c(0,.25),
      ylim =c(0,.3),lwd=3, col = "red")  #  plot the efficient frontier


for (i in 1:6) {
  points(sd_vect[i],mean_vect[i],cex = 1,pch = 16)
  text(sd_vect[i]+0.01,mean_vect[i]-0.015,symbol[i],cex=1.3)
}
legend("topleft", legend = c("Efficient frontier", "Assets","Capital Market Line", "Risk-Free Asset", "Tengency Portfolio","Min Var Portfolio"),
       col = c("red","black" ,"blue", "black", "black", "black"), 
       lty = c(1, 0,1, 0, 0,0),       # 线型，1为实线，0表示无线
       pch = c(NA,16, NA, 4, 8,1),    # 点形，NA表示无点，8为星号，19为实心圆
       merge = TRUE,              # 合并线和点的图例标示
       text.col = "black",        # 图例文字颜色
       #       bty = "n",                 # 不显示图例边框
       cex = 0.75,text.width = 0.3,  # 增加文字的宽度边距
       x.intersp = 0.3,  # 控制水平间距
       y.intersp = 0.5,
       pt.cex = 1)


mv <- matrix(nrow = 218,ncol=6)
for (i in 1:6) {
  mv[,i] <- data[,i]*final_w[i]
}
mvv <- matrix(nrow = 218,ncol=1)
for (i in 1:218) {
  mvv[i,] <- mv[i,1]+mv[i,2]+mv[i,3]+mv[i,4]+mv[i,5]+mv[i,6]
}

w_bl <- c(0.243856,0.138649,0.271898,0.133799,0.243437,0.369787)

bl <- matrix(nrow = 218,ncol=6)
for (i in 1:6) {
  bl[,i] <- data[,i]*w_bl[i]
}
bll <- matrix(nrow = 218,ncol=1)
for (i in 1:218) {
  bll[i,] <- bl[i,1]+bl[i,2]+bl[i,3]+bl[i,4]+bl[i,5]+bl[i,6]
}
w_n <- rep(1/6,6)

n <- matrix(nrow = 218,ncol=6)
for (i in 1:6) {
  n[,i] <- data[,i]*w_n[i]
}
nn <- matrix(nrow = 218,ncol=1)
for (i in 1:218) {
  nn[i,] <- n[i,1]+n[i,2]+n[i,3]+n[i,4]+n[i,5]+n[i,6]
}

symbols <- c("0050", "0056", "006208", "00713", "00712", "00692", "00646", "00757", "00830", "00733")

data_etf <- matrix(nrow = 218,ncol=10)
for (i in 1:length(symbols)){
  filename <- paste("C:\\Users\\user\\OneDrive\\Desktop\\ETF\\",symbols[i],"_daily.xlsx",sep = "")
  etf <- read_xlsx(filename)
  etf <- as.data.frame(etf)
  etf$date <- as.Date(etf$date)
  etf <- etf[1:218,]
  etf <- etf[order(etf$date), ]
  rownames(etf) <- NULL
  etf <- etf$close
  data_etf[,i] <- etf
}
filename <- paste("C:\\Users\\user\\OneDrive\\Desktop\\ETF\\",symbols[1],"_daily.xlsx",sep = "")
etf <- read_xlsx(filename)
etf <- as.data.frame(etf)
etf$date <- as.Date(etf$date)
etf <- etf[1:218,]
etf <- etf[order(etf$date), ]
dates <- etf$date
# 转换矩阵为数据框
df <- as.data.frame(data_etf)
# 添加日期列至数据框
df <- cbind(date = dates, df,mvv,bll,nn)  # 将日期列添加到数据框的最前面
names(df) <- c("date",symbols,"MV","BL","1/N")  # 设置列名为ETF的标识符

# 查看数据框结构
print(head(df))
library(tidyr)
library(ggplot2)
df$date <- as.Date(df$date)
# 将df从宽格式转换为长格式，适合绘图
df_long <- pivot_longer(df, 
                        cols = -date, 
                        names_to = "Name", 
                        values_to = "Close")
library(dplyr)
library(ggplot2)
library(tidyr)
# 计算日回报率
df_long <- df_long %>%
  group_by(Name) %>%
  arrange(Name, date) %>%
  mutate(Return = Close / lag(Close) - 1) %>%
  replace_na(list(Return = 0)) %>%
  ungroup()

# 计算累计回报
df_long <- df_long %>%
  group_by(Name) %>%
  mutate(CumulativeReturn = cumsum(Return)) %>%
  ungroup()

ggplot(df_long, aes(x = date, y = CumulativeReturn, color = Name, 
                    size = interaction(Name %in% c("MV", "BL","1/N")))) +
  geom_line() +  # 使用线条表示趋势
  labs(title = "Cumulative returns of profolio optimization strategies and 10 ETFs", x = "Date", y = "Cumulative returns") +
  theme_minimal() +
  scale_color_viridis_d(option = "turbo") +  # 使用一个美观的颜色方案
  scale_size_manual(values = c("FALSE" = 0.5, "TRUE" = 0.75)) +  # 控制线宽
  guides(size = FALSE)  # 隐藏线宽图例
