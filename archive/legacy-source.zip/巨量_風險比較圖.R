setwd("C:\\Users\\user\\OneDrive\\Desktop\\ETF\\")
library(readxl)
symbols <- c("0050", "0056", "00646", "00692", "00712",
            "00713","00733", "00757", "00830", "006208")

return_list = c()
for (i in 1:length(symbols)){
  filename <- paste(symbols[i],"_daily.xlsx",sep = "")
  data <- read_xlsx(filename)
  data <- as.data.frame(data)
  data$date <- as.Date(data$date)
  data <- data[order(data$date), ]
  rownames(data) <- NULL
  data_ts <- ts(data$close,start=c(2019,1), frequency=299)
  data_ts = diff(log(data_ts))
}

risk <- data.frame(name=c(symbols,"MV","BL","1/N"),
                   volatility=c(rep(0,10),0.93,0.18,32.05))
for (i in 1:10) {
  # 计算日收益率
  returns <- diff(log(data[,i]))
  # 计算日收益率的标准差
  sigma_daily <- sd(returns)
  # 年化日标准差
  sigma_annual <- sigma_daily * sqrt(218)
  # 输出年化波动性
  risk[i,2] <- round(sigma_annual,2)
}
risk <- risk[order(risk$volatility),]
risk$name <- factor(risk$name, levels = risk$name)
ggplot(risk, aes(x = name, y = volatility, fill = name)) +
  geom_bar(stat = "identity", position = "dodge") +
  labs(title = "投資組合與ETF風險比較", x = "投資組合與10支ETF", y = "risk") +
  theme_minimal() +
  scale_fill_manual(values = c("gray","gray","gray","gray","gray","gray","#2E9FDF","gray","gray","gray","gray","#E7B800" , "coral"))

