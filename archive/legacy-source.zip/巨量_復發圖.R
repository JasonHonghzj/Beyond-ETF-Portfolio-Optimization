##recurrance
install.packages("crqa")
library(crqa)

# 創建一個時間序列數據
library(readxl)
setwd("/Users/lintaijung/Desktop/daily_/")
data1 = read_xlsx("2412_daily.xlsx")
data2 = read_xlsx("6505_daily.xlsx")
data1 = as.data.frame(data1)
data1$date = as.Date(data1$date)
data1 = data1[order(data1$date), ]
data1_ts <- ts(data1$close, start = c(2019, 1), frequency = 250)
data2 = as.data.frame(data2)
data2$date = as.Date(data2$date)
data2 = data2[order(data2$date), ]
merged_data <- merge(data1, data2, by = "date", all = TRUE)
merged_data <- merged_data[complete.cases(merged_data), ]
data2_ts <- ts(data2$close, start = c(2019, 1), frequency = 250)
ts1 <- ts(merged_data$close.x,start = c(2019,1),frequency = 250)
ts2 <- ts(merged_data$close.y,start = c(2019,1),frequency = 250)
# 計算相關復發矩陣
rp_matrix <- crqa(ts1, ts2)
rp_matrix <- rp_matrix$RP
# 繪製復發圖
plotRP(rp_matrix)