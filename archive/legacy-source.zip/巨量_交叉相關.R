s1 <- read_xlsx("/Users/lintaijung/Desktop/ETF/0050_daily.xlsx")
s2 <- read_xlsx("/Users/lintaijung/Desktop/ETF/00646_daily.xlsx")
stock1 <- diff(log(s1$close))  
stock2 <- diff(log(s2$close))  
# 確保數據對齊
stocks <- na.omit(merge(stock1, stock2))
# 使用ccf計算並繪製互相關
ccf_result <- ccf(stocks[,1], stocks[,2], lag.max=20, main="Cross-correlation between 0050 and 00646")

library(readxl)
library(tseries)
par(mfrow=c(5,5))
for (i in 1:30){
  for (j in 1:30){
    if (i<j){
      filename1 <- paste("/Users/lintaijung/Desktop/daily_/",symbol[i],"_daily.xlsx",sep = "")
      filename2 <- paste("/Users/lintaijung/Desktop/daily_/",symbol[j],"_daily.xlsx",sep = "")
      data1 <- read_xlsx(filename1)
      data1 <- as.data.frame(data1)
      data1$date <- as.Date(data1$date)
      data1 <- data1[order(data1$date), ]
      data2 <- read_xlsx(filename2)
      data2 <- as.data.frame(data2)
      data2$date <- as.Date(data2$date)
      data2 <- data2[order(data2$date), ]
      rownames(data1) <- NULL
      rownames(data2) <- NULL
      
      #合併兩個股票的數據，按照日期合併
      merged_data <- merge(data1, data2, by = "date", all = TRUE)
      
      # 去除不匹配的行
      merged_data <- merged_data[complete.cases(merged_data), ]
      
      stock1 <- diff(log(merged_data$close.x))  # 第一支股票的收盤價
      stock2 <- diff(log(merged_data$close.y))  # 第二支股票的收盤價
      stocks <- data.frame(stock1, stock2)
      
      # 使用ccf計算並繪製互相關
      p <- ccf(stocks[,1], stocks[,2], lag.max=20, main=paste("Cross-correlation between", symbol[i], "&", symbol[j]),ylim = c(-0.2,0.9))
      plot_filename <- paste(symbol[i],"&",symbol[j], "_plot.png", sep = "")
      png(plot_filename, width = 800, height = 600)  # 調整圖形大小
      plot(p) # 直接繪製 ACF 圖形
      dev.off()
    }
  }
}