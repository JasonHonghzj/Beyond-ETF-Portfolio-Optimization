library(RColorBrewer)

# MV
a <- data.frame("group" = c('3711','3034','2886','2454','2357'),
                "subject" = c(0.004,0.244,0.440,0.129,0.184))

# 计算百分比
percentages <- a$subject / sum(a$subject) * 100

# 创建带百分比的标签
labels <- paste(a$group, sprintf("(%.1f%%)", percentages))

# 绘制饼图
myPalette <- brewer.pal(5, "Set2")
pie(a$subject, labels = labels, main = "MV模型配適之投資組合圓餅圖",col=myPalette
    ,cex=1.5,cex.main=1.5)


#BL
a <- data.frame("group" = c('3711','3034','2886','2454','2357','2330'),
                "subject" = c(0.17,0.18,0.09,0.19,0.08,0.283))

# 计算百分比
percentages <- a$subject / sum(a$subject) * 100

# 创建带百分比的标签
labels <- paste(a$group, sprintf("(%.1f%%)", percentages))


# 绘制饼图
myPalette <- brewer.pal(6, "Set2")
pie(a$subject, labels = labels, main = "BL模型配適之投資組合圓餅圖",col=myPalette
    ,cex=1.5,cex.main=1.5)

