#BL Model
#Stock
library(readxl)
setwd("C:\\Users\\user\\OneDrive\\Desktop\\stock_data\\")

symbol <- c("3034","2357","2454","2886","3711","2330")

whole = list()
meanas = c()

for (i in 1:length(symbol)){
  filename <- paste(symbol[i],"_daily.xlsx",sep = "")
  data <- read_xlsx(filename)
  data <- as.data.frame(data)
  data$date <- as.Date(data$date)
  data <- data[order(data$date), ]
  rownames(data) <- NULL
  data$close <- ts(data$close,start=c(2019,1), frequency=299)
  
  return_rate_list = list()
  for (s in 2:nrow(data)){
    return_rate = (data$close[s] - data$close[s-1]) / data$close[s-1]
    return_rate_list[[s-1]] = return_rate
  }
  
  whole[[i]]<- as.data.frame(do.call(rbind, return_rate_list))
  
  meanas = c(meanas,mean(data$close))
}
whole_df <- do.call(cbind, whole)


for (k in 1:length(symbol)){
  return <- paste(symbol[k],"return",sep = "_")
  colnames(whole_df)[k] = return
}
head(whole_df)

covariance = cov(whole_df)
covar<-as.matrix(covariance)

#Define the QP
Dmat <- 2*covar
dvec <- rep(0,length(symbol))
Amat <- matrix(c(meanas,-meanas,rep(1,length(symbol))
                 ,rep(-1,length(symbol)),diag(length(meanas))),nrow = 6,ncol=10)

# compute efficient frontier for eight stocks
varP=vector()
sigmaP=vector()
w1=vector()
w2=vector()
w3=vector()
w4=vector()
w5=vector()
w6=vector()

#Expected Returns 20 values
Rvals=seq(min(meanas)+0.1^10,max(meanas)-0.1^10,length.out=20);

#install.packages("quadprog")
library(quadprog)
for (i in 1:length(Rvals)) {
  R = Rvals[i]
  bvec <- c(R,-R,1,-1,rep(0,6))
  qpSol=solve.QP(Dmat,dvec,Amat,bvec)
  varP[i]=qpSol$value
  sigmaP[i]=sqrt(varP[i])
  w1[i]=qpSol$solution[1];
  w2[i]=qpSol$solution[2];
  w3[i]=qpSol$solution[3];
  w4[i]=qpSol$solution[4];
  w5[i]=qpSol$solution[5];
  w6[i]=qpSol$solution[6];
}

#Portfolio weights
weightsoutput <- data.frame(w1,w2,w3,w4,w5,w6)
for (t in 1:length(symbol)){
  weight <- paste(symbol[t],"權重",sep = "_")
  colnames(weightsoutput)[t] = weight
}
#Checking whether summation is equal to one
weightsum <- apply(weightsoutput,1,sum)

#https://rpubs.com/RajeshVegi/Portfolio_optimization